package com.familyhealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FamilyHealthApplication {
    public static void main(String[] args) {
        SpringApplication.run(FamilyHealthApplication.class, args);
    }
}